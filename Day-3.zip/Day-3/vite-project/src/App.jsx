
import './App.css'
import Login from './Pages/Login'
import Signup from './Pages/Signup'

function App() {

  return (
    <>
      <Signup />
      <Login/>
    </>
  )
}

export default App
