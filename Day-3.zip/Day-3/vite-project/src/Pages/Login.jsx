import React from 'react'
import { useState } from 'react'
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";


import { auth } from '../firebase';


export default function Login() {
    // const auth = getAuth();

    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")

    const handleLogin = (e) => {
        e.preventDefault();

        signInWithEmailAndPassword(auth, email, password)
            .then((userCredential) => {
                // Signed up 
                const user = userCredential.user;
                console.log("login successfull", user.accessToken)

                // ...
            })
            .catch((error) => {
                const errorCode = error.code;
                const errorMessage = error.message;
                console.log(errorCode)
                console.log(errorMessage)
                // ..
            })
    }

    return (
        <div>
            <form onSubmit={handleLogin} >
                <input placeholder='enter email' value={email} onChange={(e) => setEmail(e.target.value)} type="text" /> <br /><br />

                <input placeholder='enter password' value={password} onChange={(e) => setPassword(e.target.value)} type="text" /> <br /><br />

                <button>Login</button>
            </form>
        </div>
    )
}
