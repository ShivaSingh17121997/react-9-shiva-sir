
import './App.css'
import Counter from './Pages/Counter'

function App() {

  return (
    <>
      <h1>Counter App with REDUX</h1>
      <Counter />
    </>
  )
}

export default App
