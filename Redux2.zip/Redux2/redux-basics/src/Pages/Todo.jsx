import React, { useState, useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ADD_TODO, DELETE_TODO, GET_TODO, UPDATE_TODO } from '../Redux/ActionTypes';
import axios from 'axios';

export default function Todo() {
    const [inputData, setInputData] = useState("");
    const [edit, setEdit] = useState(null);
    const [completed, setCompleted] = useState(false);
    const [category, setCategory] = useState("");
    const dispatch = useDispatch();

    const todoData = useSelector(store => store.todo);

    const handleTodoSubmit = (e) => {
        e.preventDefault();

        if (edit) {
            // Update todo
            axios.patch(`http://localhost:9090/todo/${edit.id}`, {
                todo: inputData,
                completed: completed,
                category: category
            })
                .then((res) => {
                    console.log("data updated successfully");
                    dispatch({ type: UPDATE_TODO, payload: res.data });
                    setInputData("");
                    setCompleted(false);
                    setCategory("");
                    setEdit(null);
                });
        } else {
            // Add new todo
            axios.post(`http://localhost:9090/todo`, {
                todo: inputData,
                completed: completed,
                category: category
            })
                .then((res) => {
                    console.log("data added successfully");
                    dispatch({ type: ADD_TODO, payload: res.data });
                    setInputData("");
                    setCompleted(false);
                    setCategory("");
                });
        }
    };

    // get data
    useEffect(() => {
        axios.get(`http://localhost:9090/todo`)
            .then((res) => {
                console.log(res.data);
                dispatch({ type: GET_TODO, payload: res.data });
            });
    }, [dispatch]);

    // delete
    const handleDelete = (id) => {
        axios.delete(`http://localhost:9090/todo/${id}`)
            .then((res) => {
                console.log("data deleted successfully", res.data);
                dispatch({ type: DELETE_TODO, payload: id });
            });
    };

    // edit
    const handleEdit = (id) => {
        const isEdited = todoData.find((item) => item.id === id);
        setEdit(isEdited);
        setInputData(isEdited.todo);
        setCompleted(isEdited.completed);
        setCategory(isEdited.category);
    };

    console.log(completed);
    console.log(category);

    return (
        <div>
            <h1>Todo app with redux</h1>
            <form onSubmit={handleTodoSubmit} >
                <input value={inputData} onChange={(e) => setInputData(e.target.value)} type="text" placeholder='Enter Your todo' /> <br />


                <label >
                    <input type="checkbox" checked={completed} onChange={(e) => setCompleted(e.target.checked)} />
                    Completed
                </label> <br />


                 
                <select value={category} onChange={(e) => setCategory(e.target.value)} id="">
                    <option value=""></option>
                    <option value="public">Public</option>
                    <option value="personal">Personal</option>
                    <option value="home">Home</option>
                </select>
                <button>{edit ? "Update" : "Add"}</button>
            </form>

            <div>
                {
                    todoData.map((item) => {
                        return <div key={item.id}>
                            <h4>{item.todo}</h4>
                            <h4>{item.completed ? "Completed" : "Not Completed"}</h4>
                            <h5>{item.category}</h5>
                            <button onClick={() => handleEdit(item.id)}>Edit</button>
                            <button onClick={() => handleDelete(item.id)}>Delete</button>
                        </div>
                    })
                }
            </div>
        </div>
    );
}
