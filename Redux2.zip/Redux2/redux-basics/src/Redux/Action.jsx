import { DECREMENT, INCREMENT, RESET } from "./ActionTypes"


export const AddAction = (payload) => {
    return { type: INCREMENT, payload: payload }
}

export const ReducerAction = (payload) => {
    return { type: DECREMENT, payload: payload }
}


export const ResetAction = () => {
    return { type: RESET }
}