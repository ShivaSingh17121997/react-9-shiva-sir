

//counter
export const INCREMENT = "INCREMENT"

export const DECREMENT = "DECREMENT"

export const RESET = "RESET"


//todo
export const ADD_TODO = "ADD_TODO"
export const GET_TODO = "GET_TODO"
export const DELETE_TODO = "DELETE_TODO"
export const UPDATE_TODO = "UPDATE_TODO"