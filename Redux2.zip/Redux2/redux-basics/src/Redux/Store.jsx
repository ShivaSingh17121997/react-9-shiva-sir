import { legacy_createStore } from 'redux';
import Reducer from './Reducer';

const initialState = {
    count: 0,
    todo: [],
    isAuth: false,
    theme: false
}

export const store = legacy_createStore(Reducer, initialState)


