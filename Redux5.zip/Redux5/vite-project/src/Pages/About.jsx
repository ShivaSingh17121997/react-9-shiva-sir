import React from 'react'

export default function About() {
  return (
    <div>
      <h1>About</h1>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Incidunt ducimus debitis nesciunt aliquid perspiciatis quia ad dolorum repellat, mollitia, aspernatur fugit laboriosam quae minus voluptatum placeat optio sed laborum voluptate!</p>
    </div>
  )
}
