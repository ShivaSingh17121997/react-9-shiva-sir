import React from 'react'

export default function Contacts() {
  return (
    <div>
      <h3>Contacts</h3>
      <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Dolorem odio nesciunt aliquam cum quo ut est nemo inventore tempora ab commodi dolores reiciendis id tempore libero aut consequuntur, eos laborum.</p>
    </div>
  )
}
