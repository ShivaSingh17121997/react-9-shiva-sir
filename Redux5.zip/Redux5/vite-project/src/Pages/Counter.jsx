import React from 'react'

export default function Counter() {
  return (
    <div>
        Counter
    </div>
  )
}
